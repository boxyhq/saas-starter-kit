-- AlterTable
ALTER TABLE "User" ALTER COLUMN "password" DROP NOT NULL;
