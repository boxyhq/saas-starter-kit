-- AlterTable
ALTER TABLE "jackson_store" ALTER COLUMN "namespace" SET DATA TYPE VARCHAR(256);
