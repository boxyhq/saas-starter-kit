-- CreateIndex
CREATE INDEX "Team_billingId_idx" ON "Team"("billingId");
