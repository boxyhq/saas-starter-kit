import { createContext } from 'react';

const ResumeContext = createContext(null);

export default ResumeContext;
