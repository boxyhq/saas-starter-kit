


const Resume = () => {
   return (
   
       <h1>Hello</h1>
       
  )
};

export default Resume;
