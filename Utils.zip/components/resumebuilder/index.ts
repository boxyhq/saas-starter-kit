export { default as Resume } from './Resume';

